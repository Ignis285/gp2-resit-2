#include "MainGameBoy.h"
#include "CameraBoy.h"
#include <iostream>
#include <string>


//Transforms for each mesh
Transform Transform1;
Transform Transform2;
Transform Transform3;
Transform Transform4;
Transform Transform5;

MainGameBoy::MainGameBoy()
{
	_gameState = GameState::PLAY;
	DisplayBoy* _gameDisplay = new DisplayBoy(); //new display
    MeshBoy* CatBoy();	//Cat Mesh
	MeshBoy* RockBoy();	//Rock Mesh
	MeshBoy* Box();	//Box Mesh
	ShaderBoy* shaderBlur2();	//Blur Shader
	ShaderBoy* shaderToonRim2();	//ToonRim Shader
}

MainGameBoy::~MainGameBoy() 
{
}

void MainGameBoy::runBoy() // Runs Method on start up
{
	initializeSystemsBoy();
	gameLoopBoy();
}

void MainGameBoy::initializeSystemsBoy()	//initializes the game
{
	_gameDisplayPlz.initDisplay(); 
	//Initializes all used shaders
	shaderBlur.initializePlz("..\\res\\shaderBlur.vert", "..\\res\\shaderBlur.frag");
	toonRimShaderBoy.initializePlz("..\\res\\shaderToonRim.vert", "..\\res\\shaderToonRim.frag");

	//Initializes all used models
	CatBoy.loadModelPlz("..\\res\\cat.obj");
	RockBoy.loadModelPlz("..\\res\\Rocky.obj");
	Box.loadModelPlz("..\\res\\monkey3 - Copy.obj");
	
	//Initializes  camera and sets its position, size and direction
	theCamera2.initCamera2(glm::vec3(0, 0, -10.0), 70.0f, (float)_gameDisplayPlz.getWidthPlz()/_gameDisplayPlz.getHeightPlz(), 0.01f, 1000.0f);

	ExplodeBoy = SoundBoy.loadSound2("..\\res\\bang.wav");

	transformCounter2 = 1.0f;	//sets Counter for later use
	transformCounter11 = 0.0f;	//sets second counter for later use
	LeftMove = false;
	xpos = 0;
	xposRock = 0;
	ymonk = 20;
}

void MainGameBoy::gameLoopBoy()	//Runs while game us runing
{
	while (_gameState != GameState::EXIT)
	{
		if (xpos > 6.7)
			xpos = -6.6;
		if (xpos < -6.7)
			xpos = 6.6;
		processInputsBoy();	//Runs all used inputes, constantly checking if they are being used
		drawGameBoy();	//Constantly running the drawgame method
	}
}

void MainGameBoy::processInputsBoy()	//Used for all user inputs to game
{
	SDL_Event evnt;

	while(SDL_PollEvent(&evnt)) //get and process events
	{
		switch (evnt.type)
		{
		case SDL_KEYDOWN:
				switch (evnt.key.keysym.sym)
				{
				case SDLK_ESCAPE:	//Closes game when "escape" is pressed
					_gameState = GameState::EXIT;
					break;
				case SDLK_a:	//Movs character left
					xpos += 0.1f;
					break;
				case SDLK_d:	//Moves Character right
					xpos -= 0.1f;
					break;
				case SDLK_SPACE:	//Fires projectile
					cout << "sace working " <<xpos;
					ymonk = -4;
					xmonk = xpos;
					break;
				}
		}
	}
	
}

void MainGameBoy::setToonRimShader()	//Sets values for toon Rim shader
{
	toonRimShaderBoy.setVec3Plz("lightDir", glm::vec3(0.5, 0.5, 0.5));	
	toonRimShaderBoy.setMat4Plz("u_vm", theCamera2.GetView());
	toonRimShaderBoy.setMat4Plz("u_pm", theCamera2.GetProjection());
	toonRimShaderBoy.setMat4Plz("v_pos", Transform3.GetModel());
}

void MainGameBoy::blobEffect()	//Sets values for blur shader
{
	GLuint blockIndex = glGetUniformBlockIndex(shaderBlur.getProgramPlz(), "BlobSettings");

	GLint blockSize;
	glGetActiveUniformBlockiv(shaderBlur.getProgramPlz(), blockIndex,
		GL_UNIFORM_BLOCK_DATA_SIZE, &blockSize); //get information about blobsettings and save it in blockSize

	GLubyte * blockBuffer = (GLubyte *)malloc(blockSize); //allocates the requested memory and returns a pointer to it.

														  // Query for the offsets of each block variable
	const GLchar *names[] = { "InnerColor", "OuterColor",
		"RadiusInner", "RadiusOuter" };

	GLuint indices[4];
	glGetUniformIndices(shaderBlur.getProgramPlz(), 4, names, indices); // glGetUniformIndices retrieves the indices of a number of uniforms within program

	GLint offset[4];
	glGetActiveUniformsiv(shaderBlur.getProgramPlz(), 4, indices, GL_UNIFORM_OFFSET, offset); //Returns information about several active uniform variables for the specified program object

	GLfloat outerColor[] = { 0.0f, 0.0f, 0.0f, 0.0f };
	GLfloat innerColor[] = { 1.0f, 1.0f, 0.75f, 1.0f };

	GLfloat innerRadius = 0.0f, outerRadius = 3.0f;

	memcpy(blockBuffer + offset[0], innerColor,
		4 * sizeof(GLfloat)); //destination, source, no of bytes. 
	memcpy(blockBuffer + offset[1], outerColor,
		4 * sizeof(GLfloat));
	memcpy(blockBuffer + offset[2], &innerRadius,
		sizeof(GLfloat));
	memcpy(blockBuffer + offset[3], &outerRadius,
		sizeof(GLfloat));

	GLuint uboHandle;

	glGenBuffers(1, &uboHandle);

	glBindBuffer(GL_UNIFORM_BUFFER, uboHandle);
	glBufferData(GL_UNIFORM_BUFFER, blockSize, blockBuffer,
		GL_DYNAMIC_DRAW); //creates and initializes a buffer object's data store - targer, size, data, usage

	glBindBufferBase(GL_UNIFORM_BUFFER, blockIndex, uboHandle); // bind a buffer object to an indexed buffer target - trager, index, buffer
}

void MainGameBoy::drawGameBoy()	//Draw game method is constantly updating as game is running
{	
	transformCounter11 = transformCounter11 + 0.1f;
	_gameDisplayPlz.clearDisplayPlz(0.0f, 0.0f, 0.0f, 1.0f);
	//Calls methods to draw each model and bind shaders
	MeshDrawCat();
	MeshDrawRock();
	MeshDrawBox();

	oncollide();
	transformCounter2 = transformCounter2 + 0.01f;

	glEnableClientState(GL_COLOR_ARRAY); 
	glEnd();

	_gameDisplayPlz.swapBufferPlz();

} 

void MainGameBoy::oncollide()
{
	if (CollisionProcessing(Box.getSpherePos(), Box.getSphereRadius(), RockBoy.getSpherePos()
		, RockBoy.getSphereRadius()) == true)
	{
		xposRock = 5.5;
		ymonk = 20;
		SoundPlay(ExplodeBoy, glm::vec3(0.0, 0.0, 0.0));
	}
}

void MainGameBoy::SoundPlay(unsigned int Clip, glm::vec3 soundpos)
{
	ALint SoundState;
	alGetSourcei(Clip, AL_SOURCE_STATE, &SoundState);
	if (AL_PLAYING != SoundState)
	{
		SoundBoy.playSoundPlz(Clip, soundpos);
	}
}

void MainGameBoy::MeshDrawCat()
{
	TextureBoy Furboy("..\\res\\fur1.jpg");
	//Sets method positions 
	Transform1.SetPos2(glm::vec3(xpos, -4.0, 0.0f ));
	Transform1.SetRot2(glm::vec3(-90.0, 0.0, 0.0));
	Transform1.SetScale2(glm::vec3(1.0, 1.0, 1.0));

	//Binds fog shader and sets shader up
	//shaderPhong.BindPlz();
	//setFogShader(Cat.getSpherePos().z + 4.0);
	toonRimShaderBoy.BindPlzshader();
	toonRimShaderBoy.UpdateStuffPlz(Transform1, theCamera2);
	Furboy.BindPlz2(0);
	//Draws Model and updates sphere postion
	CatBoy.drawPlz();
	CatBoy.updateSphereDataBoy(*Transform1.GetPos2(), 0.62f);
}

void MainGameBoy::MeshDrawRock()
{
	TextureBoy stone("..\\res\\bricks.jpg");
	//Sets method positions 
	Transform3.SetPos2(glm::vec3(xposRock, 3.5, 0.0));
	Transform3.SetRot2(glm::vec3(0, 0, 0));
	Transform3.SetScale2(glm::vec3(0.3, 0.3, 0.3));

	//Binds rim shader
	toonRimShaderBoy.BindPlzshader();
	toonRimShaderBoy.UpdateStuffPlz(Transform3, theCamera2);
	stone.BindPlz2(0);
	//Draws model and updates sphere positon
	RockBoy.drawPlz();
	RockBoy.updateSphereDataBoy(*Transform3.GetPos2(), 0.62f);
	MoveLoop();
}

void MainGameBoy::MeshDrawBox()
{
	TextureBoy stone("..\\res\\bricks.jpg");
	//Sets method positions 
	Transform5.SetPos2(glm::vec3(xmonk, ymonk,0));
	Transform5.SetRot2(glm::vec3(0, 0, 0));
	Transform5.SetScale2(glm::vec3(0.5, 0.5, 0.5));
	//Binds either phong or blinn-phong shader
	toonRimShaderBoy.BindPlzshader();
	toonRimShaderBoy.UpdateStuffPlz(Transform5, theCamera2);
	//Draws model and updates sphere positon
	//Draws model and updates sphere positon
	stone.BindPlz2(0);
	Box.drawPlz();
	Box.updateSphereDataBoy(*Transform5.GetPos2(), 0.62f);
}

bool MainGameBoy::CollisionProcessing(glm::vec3 MonkeyPos, float MonkeyRad, glm::vec3 RockPos, float RockRad) //checks for collisions
{
	float DistanceBetweenModels = glm::sqrt((RockPos.x - MonkeyPos.x)*(RockPos.x - MonkeyPos.x) + (RockPos.y - MonkeyPos.y)*(RockPos.y - MonkeyPos.y) + (RockPos.z - MonkeyPos.z)*(RockPos.z - MonkeyPos.z));

	if (DistanceBetweenModels < (MonkeyRad + RockRad))
	{
		return true;
	}
	else
	{
		return false;
	}

}

void MainGameBoy::MoveLoop()
{
	if (xposRock >= 5.5)
		LeftMove = true;
	if (xposRock <= -5.5)
		LeftMove = false;
	if (LeftMove == true)
		xposRock -= 0.2;
	if (LeftMove == false)
		xposRock += 0.2f;
	ymonk += 0.2;
}