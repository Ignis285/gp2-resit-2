#pragma once
#include <SDL/SDL.h>
#include <GL\glew.h>
#include <iostream>
#include <string>
using namespace std;


class DisplayBoy
{
public:
	DisplayBoy();
	~DisplayBoy();
	void initDisplay();
	void swapBufferPlz();
	void clearDisplayPlz(float r, float g, float b, float a);

	float getWidthPlz();
	float getHeightPlz();

private:

	void returnError(std::string errorString);
	
	SDL_GLContext glContext; //global variable to hold the context
	SDL_Window* sdlWindowPlz; //holds pointer to out window
	float screenWidthPlz;
	float screenHeightPlz;
};

