#pragma once
#include <SDL\SDL.h>
#include <GL/glew.h>
#include "DisplayBoy.h" 
#include "ShaderBoy.h"
#include "MeshBoy.h"
#include "TextureBoy.h"
#include "transformBoy.h"
#include "AudioBoy.h"
#include "OverlayBoy.h"

enum class GameState{PLAY, EXIT};

class MainGameBoy
{
public:
	MainGameBoy();
	~MainGameBoy();

	void runBoy();

private:

	void initializeSystemsBoy();
	void processInputsBoy();
	void gameLoopBoy();
	void drawGameBoy();
	void blobEffect();
	//void setRimShader();
	void setToonRimShader();
	/*void setBlinnPhong();
	void setFogShader(float Z_pos);
	void setPhong();*/
	void MeshDrawCat();
	//void Mesh2Draw();
	void MeshDrawRock();
	//void Mesh4Draw();
	void MeshDrawBox();
	void MoveLoop();
	void oncollide();
	void SoundPlay(unsigned int Clip, glm::vec3 soundpos);

	DisplayBoy _gameDisplayPlz;
	GameState _gameState;
	MeshBoy CatBoy;
	//MeshBoy Tree;
	MeshBoy RockBoy;
	//MeshBoy Bird;
	MeshBoy Box;
	ShaderBoy shaderBlur;
	//ShaderBoy shaderRim;
	ShaderBoy toonRimShaderBoy;
	//ShaderBoy shaderFog;
	//ShaderBoy blinnPhongShader;
	//ShaderBoy shaderPhong;
	AudioBoy SoundBoy;

	glm::mat4 modelView1;

	CameraBoy theCamera2;

	unsigned int ExplodeBoy;
	unsigned int backBoy;

	float transformCounter2;
	float transformCounter11;
	float xpos;
	float xposRock;
	float xmonk;
	float ymonk;
	bool LeftMove;
	bool CollisionProcessing(glm::vec3 MonkeyPos, float MonkeyRad, glm::vec3 RockPos, float RockRad); //checks for collisions
	bool spacepressed;
};

