#pragma once
#include <string>
#include <GL\glew.h>

class TextureBoy
{
public:
	TextureBoy(const std::string& fileName);

	void BindPlz2(unsigned int unit); // bind upto 32 textures
	void init(const std::string& fileName);
	~TextureBoy();
	GLint getTexHandler() { return textureHandler; }

protected:
private:

	GLuint textureHandler;
};

