#include <iostream>
#include "MainGameBoy.h"

int main(int argc, char** argv) //argument used to call SDL main
{
	MainGameBoy mainGame;
	mainGame.runBoy();

	return 0;
}