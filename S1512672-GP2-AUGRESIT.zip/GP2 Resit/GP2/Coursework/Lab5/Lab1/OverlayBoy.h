//#pragma once
//#include <string>
//#include "TextureBoy.h"
//#include "DisplayBoy.h"
//#include "MeshBoy.h"
//#include <gl\glew.h>
//#include <glm\glm.hpp>
//#include <vector>
//
//
//class OverlayBoy
//{
//public:
//	OverlayBoy();
//	~OverlayBoy();
//	void drawOL(GLuint program);
//	void init(const std::string& fileName);
//
//private:
//	TextureBoy texture;
//};
//
