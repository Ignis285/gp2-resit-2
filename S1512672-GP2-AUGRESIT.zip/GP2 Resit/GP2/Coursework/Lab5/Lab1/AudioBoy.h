#pragma once

#include <glm\glm.hpp>
#include <AL\al.h>
#include <AL\alc.h>
#include <vector>
#include <cstring>
#include <string>
#include <iostream>
#include <fstream>
#include <SDL\SDL.h>
#include <glm/gtc/type_ptr.hpp>

class AudioBoy
{
	struct data {
		int sourceID, bufferID;
		char* buffer;
		std::string name;
		data(unsigned int sI, unsigned int bI, char* b, const char* n)
		{
			this->sourceID = sI;
			this->bufferID = bI;
			this->buffer = b;
			this->name = n;
		}

	};

	struct Vector3
	{
		float x, y, z;
	};
	std::vector<data> datas;
	ALCcontext* context;
	ALCdevice *devicePlz;
	bool isBigEndianPlz();
	int convertToIntPlz(char* buffer, int length);
	char* loadWAVPlz(const char* fn, int& chan, int& samplerate, int& bps, int& size);

public:
	AudioBoy();
	~AudioBoy();
	unsigned int loadSound2(const char* filename);
	void deleteSoundPlz(unsigned int id);
	void playSoundPlz(unsigned int id);
	void playSoundPlz(unsigned int id, glm::vec3& pos);
	void stopSoundPlz(unsigned int id);
	void setlistenerPlz(glm::vec3& pos, glm::vec3& camLookAt);
	void setSoundPositionPlz(unsigned int id, glm::vec3& pos);

private:
	
};

