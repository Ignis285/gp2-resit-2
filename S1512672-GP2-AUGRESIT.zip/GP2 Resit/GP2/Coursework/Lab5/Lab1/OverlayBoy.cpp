#include "OverlayBoy.h"
//#include "ShaderBoy.h"
//
//
//OverlayBoy::OverlayBoy()
//{
//	TextureBoy* texture();
//}
//
//void OverlayBoy::init(const std::string& fileName)
//{
//	texture.init("..\\res\\bricks.jpg");
//}
//
//
//void OverlayBoy::drawOL(GLuint program)
//{
//	texture.Bind(0);
//	// Create Vertex Array Object
//	GLuint vao;
//	glGenVertexArrays(1, &vao);
//	glBindVertexArray(vao);
//
//	// Create a Vertex Buffer Object and copy the vertex data to it
//	GLuint vbo;
//	glGenBuffers(1, &vbo);
//
//	GLfloat vertices[] = {
//		//  Position      Color             Texcoords
//		-0.5f,  0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, // Top-left
//		 0.5f,  0.5f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, // Top-right
//		 0.5f, -0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, // Bottom-right
//		-0.5f, -0.5f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f  // Bottom-left
//	};
//
//	glBindBuffer(GL_ARRAY_BUFFER, vbo);
//	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
//
//	// Create an element array
//	GLuint ebo;
//	glGenBuffers(1, &ebo);
//
//	GLuint elements[] = {
//		0, 1, 2,
//		2, 3, 0
//	};
//
//	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
//	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(elements), elements, GL_STATIC_DRAW);
//
//
//	// Specify the layout of the vertex data
//	GLint posAttrib = glGetAttribLocation(program, "position");
//	glEnableVertexAttribArray(posAttrib);
//	glVertexAttribPointer(posAttrib, 2, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), 0);
//
//	GLint colAttrib = glGetAttribLocation(program, "color");
//	glEnableVertexAttribArray(colAttrib);
//	glVertexAttribPointer(colAttrib, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)(2 * sizeof(GLfloat)));
//
//	GLint texAttrib = glGetAttribLocation(program, "texcoord");
//	glEnableVertexAttribArray(texAttrib);
//	glVertexAttribPointer(texAttrib, 2, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)(5 * sizeof(GLfloat)));
//
//	// Draw a rectangle from the 2 triangles using 6 indices
//	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
//
//	glDeleteBuffers(1, &ebo);
//	glDeleteBuffers(1, &vbo);
//
//	glDeleteVertexArrays(1, &vao);
//}
//
//OverlayBoy::~OverlayBoy()
//{
//}
